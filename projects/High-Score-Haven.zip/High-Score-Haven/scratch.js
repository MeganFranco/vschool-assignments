


// var submitTwo = function(){
//      //use .value to pull from forms
//     
//      var name = document.getElementById("userName").value;
//      var game = document.getElementById("userGame").value;
//      var date = document.getElementById("userDate").value;
//      var score = document.getElementById("userScore").value;
//	  
//
//      
//      document.getElementById("newName").innerHTML = name;
//      document.getElementById("newGame").innerHTML = game;
//      document.getElementById("newDate").innerHTML = date;
//      document.getElementById("newScore").innerHTML = score;
//      
//      	  console.log("name: " + name);
//     
// }
// 
//  document.getElementById("formSubmitTwo").onsubmit = submitTwo()
      