var app = angular.module("MyLittleBronyApp", []);

app.controller("MainController", ["$scope", "PonyService", function ($scope, PonyService) {

    $scope.favoritePonies = PonyService.poniesList
    console.log("hello")
    $scope.addPony = function () {
        console.log("hi")
        PonyService.addPony($pony)
    };

}]);









//1 call add function $scope.addpony()
//call managerService add pony
//